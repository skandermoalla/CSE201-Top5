//
//  main.cpp
//  Basketball
//
//  Created by Edison Reshketa on 10/12/2018.
//  Copyright © 2018 Edison Reshketa. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
