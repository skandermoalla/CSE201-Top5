# Top5
Basketball team manager game simulation

Top5 is a basketball team managing game. The user is assigned a team of players in a championship. 
Each season week, the user performs one basketball game. The user has the chance to interact with the game, 
by choosing the tactics, the players participating, etc. The game is broken down into subgames, 
each one corresponding to an attack or a defence. The outcome of a subgame is determined probabilistically, 
depending on the performance indices of the players of each team, and the tactic chosen. 
A user can progress from league to league, each season, depending on the performances of their team (wins and losses). 
