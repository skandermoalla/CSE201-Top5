#include "Player.cpp"
#include "Player.hpp"
#include <string>

int main (){
    Player player1 = Player::Player (std::string pos);
    cout << "Han"


}