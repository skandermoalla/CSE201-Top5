//
//  Market.hpp
//  Basketball
//

#ifndef Market_hpp
#define Market_hpp
#pragma once
#include <stdio.h>
#include "Team.hpp"
class Market
{
    
public:
    Market();
    std::vector<Player> players;
};

#endif /* Market_hpp */
