//
//  getAutomaticWinner-2.hpp
//  Basketball
//
//  Created by Edison Reshketa on 10/12/2018.
//  Copyright © 2018 Edison Reshketa. All rights reserved.
//

#ifndef getAutomaticWinner_2_hpp
#define getAutomaticWinner_2_hpp

#include <stdio.h>
#include "Team.hpp"

int getAutomaticWinner(const Team Team1, const Team Team2);

#endif /* getAutomaticWinner_2_hpp */
